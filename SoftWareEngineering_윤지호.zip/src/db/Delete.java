package db;

public class Delete {
	public boolean deleteStudent(Student student) {
		return false;
	}
}
