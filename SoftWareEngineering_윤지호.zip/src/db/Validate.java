package db;

public class Validate {
	public int requestToLogin(String id, String password) {
		return 0;
	}

	public boolean requestToLogOut() {
		return false;
	}
	
	public int checkUserIdentify(String identify) {
		return 0;
	}
	
	public void encrypt(String password) {
		
	}
}
