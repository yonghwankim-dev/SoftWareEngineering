package db;

public class Select {
	public Student getMyStudentInfo(Student student) {
		return null;
	}

	public Student[] getEveryStudentInfo(Student student) {
		return null;
	}
	
	public Student[] getSomeStudentInfo(Student student) {
		return null;
	}
}
