package db;

public class Insert {
	public boolean registerStudent(Student student) {
		return false;
	}

	public boolean registerManager(Manager manager) {
		return false;
	}
}
