package db;

public class Update {
	public Student ChangeStudentInfo(Student student) {
		return null;
	}
}
