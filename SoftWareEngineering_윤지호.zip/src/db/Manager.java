package db;

public class Manager extends User {
	public Manager(String name, String id, String password, String phoneNumber, String identify) {
		super(name, id, password, phoneNumber, identify);
		// TODO Auto-generated constructor stub
	}
}
